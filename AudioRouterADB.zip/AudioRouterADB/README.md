# Audio Router

App Android que (1) fija el micrófono del celu aunque haya auricular Bluetooth y
(2) manda el audio de cada app a la salida que elijas, con volumen propio.

Usa la conexión ADB inalámbrica al propio celu (de OptiMoto) y un ayudante que corre como "shell".

## Compilar con GitHub (te da el APK)
1. Creá un repositorio nuevo en github.com (privado o público).
2. Subí TODO el contenido de esta carpeta, incluida la carpeta oculta `.github`.
   - Desde la PC: `git init && git add -A && git commit -m init && git branch -M main`
     `git remote add origin https://github.com/TU_USUARIO/TU_REPO.git && git push -u origin main`
3. En GitHub: pestaña Actions > "build" > se ejecuta sola con cada push (o "Run workflow").
4. Cuando termine (verde, ~5 min), entrá a la ejecución y bajá "AudioRouter-apk" de Artifacts.
   Adentro del .zip está el .apk. Instalalo en el celu.
