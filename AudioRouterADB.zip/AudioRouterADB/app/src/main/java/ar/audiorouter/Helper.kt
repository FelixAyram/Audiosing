package ar.audiorouter

import android.content.Context
import android.media.*
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket

/**
 * Corre como usuario "shell" (uid 2000) lanzado con app_process por ADB inalámbrico.
 * Usa APIs @SystemApi por reflexión. Si el teléfono no le da MODIFY_AUDIO_ROUTING a shell,
 * responde con el error de Android y la app cae al modo captura.
 */
object Helper {
    private lateinit var token: String
    private lateinit var ctx: Context
    private lateinit var am: AudioManager
    private val workers = HashMap<Int, W>()
    private val INT = Int::class.javaPrimitiveType
    @Volatile private var micOn = false
    @Volatile private var lastUse = System.currentTimeMillis()

    class W(val uid: Int, @Volatile var dev: Int, @Volatile var vol: Float) { @Volatile var run = true }

    @JvmStatic
    fun main(args: Array<String>) {
        try {
            token = args.getOrNull(0) ?: ""
            System.err.println("arhelper: iniciando uid=${android.os.Process.myUid()}")
            Looper.prepareMainLooper()
            ctx = makeContext()
            System.err.println("arhelper: contexto ok (${ctx.packageName})")
            am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            Thread { serve() }.start()
            // Se cierra solo si pasan 10 min sin uso (sin apps ruteadas ni micrófono fijado): libera RAM.
            Thread {
                while (true) {
                    Thread.sleep(60_000)
                    val idle = synchronized(workers) { workers.isEmpty() } && !micOn &&
                        System.currentTimeMillis() - lastUse > 10 * 60_000
                    if (idle) System.exit(0)
                }
            }.start()
            Looper.loop()
        } catch (t: Throwable) {
            System.err.println("arhelper: FALLÓ al iniciar")
            t.printStackTrace()
            System.exit(1)
        }
    }

    private fun makeContext(): Context {
        val at = Class.forName("android.app.ActivityThread")
        try {
            val sys = at.getMethod("systemMain").invoke(null)
            return at.getMethod("getSystemContext").invoke(sys) as Context
        } catch (e: Throwable) {
            System.err.println("arhelper: systemMain falló (${e.cause ?: e}); pruebo el constructor")
            val c = at.getDeclaredConstructor(); c.isAccessible = true
            return at.getMethod("getSystemContext").invoke(c.newInstance()) as Context
        }
    }

    private fun serve() {
        val ss = try { ServerSocket(HelperClient.PORT, 5, InetAddress.getByName("127.0.0.1")) }
        catch (t: Throwable) { System.err.println("arhelper: no pude abrir el puerto: $t"); System.exit(1); return }
        System.err.println("arhelper: escuchando en ${HelperClient.PORT}")
        while (true) {
            val s = ss.accept()
            try {
                val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: ""
                val parts = line.trim().split(" ", limit = 2)
                val r = if (parts[0] != token || parts.size < 2) "ERR token"
                else try { handle(parts[1]) } catch (e: Throwable) { "ERR ${e.cause?.message ?: e.message}" }
                s.getOutputStream().apply { write("$r\n".toByteArray()); flush() }
            } catch (_: Exception) {}
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun handle(cmd: String): String {
        lastUse = System.currentTimeMillis()
        val p = cmd.split(" ")
        return when (p[0]) {
            "PING" -> "OK uid=${android.os.Process.myUid()}"
            "QUIT" -> { Thread { Thread.sleep(200); System.exit(0) }.start(); "OK" }
            "CHECK" -> { am.javaClass.getMethod("getPreferredDevicesForCapturePreset", INT).invoke(am, 1); "OK" }
            "MIC" -> mic(true)
            "MICOFF" -> mic(false)
            "SET" -> set(p[1].toInt(), p[2].toInt(), p[3].toFloat())
            "DEL" -> synchronized(workers) { workers.remove(p[1].toInt())?.run = false; "OK" }
            else -> "ERR comando desconocido"
        }
    }

    /** Micrófono del celu como preferido para todas las apps (MIC, CAMCORDER, RECONOCIMIENTO, LLAMADA, SIN PROCESAR, PERFORMANCE). */
    private fun mic(on: Boolean): String {
        val ada = Class.forName("android.media.AudioDeviceAttributes")
        val builtin = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            .first { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
        val attr = ada.getConstructor(AudioDeviceInfo::class.java).newInstance(builtin)
        val res = listOf(1, 5, 6, 7, 9, 10).map { pr ->
            try {
                if (on) am.javaClass.getMethod("setPreferredDeviceForCapturePreset", INT, ada).invoke(am, pr, attr)
                else am.javaClass.getMethod("clearPreferredDevicesForCapturePreset", INT).invoke(am, pr)
            } catch (e: Throwable) { "err:${e.cause?.message}" }
        }
        if (res.all { it is String && it.startsWith("err:") }) return "ERR ${res.first()}"
        micOn = on
        return "OK $res"
    }

    private fun set(uid: Int, dev: Int, vol: Float): String = synchronized(workers) {
        workers[uid]?.let { it.dev = dev; it.vol = vol; return "OK" }
        val w = W(uid, dev, vol)
        launch(w)
        workers[uid] = w
        "OK"
    }

    /** Mezcla "loopback" por UID: el audio de esa app deja de salir por su ruta normal y lo reproducimos nosotros. */
    private fun launch(w: W) {
        val rbC = Class.forName("android.media.audiopolicy.AudioMixingRule\$Builder")
        val rb = rbC.getConstructor().newInstance()
        rbC.getMethod("addMixRule", INT, Any::class.java).invoke(rb, 4 /* RULE_MATCH_UID */, w.uid)
        val rule = rbC.getMethod("build").invoke(rb)!!

        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
        val mbC = Class.forName("android.media.audiopolicy.AudioMix\$Builder")
        val mb = mbC.getConstructor(rule.javaClass).newInstance(rule)
        mbC.getMethod("setFormat", AudioFormat::class.java).invoke(mb, fmt)
        mbC.getMethod("setRouteFlags", INT).invoke(mb, 2 /* ROUTE_FLAG_LOOP_BACK */)
        val mix = mbC.getMethod("build").invoke(mb)!!

        val pbC = Class.forName("android.media.audiopolicy.AudioPolicy\$Builder")
        val pb = pbC.getConstructor(Context::class.java).newInstance(ctx)
        pbC.getMethod("setLooper", Looper::class.java).invoke(pb, Looper.getMainLooper())
        pbC.getMethod("addMix", mix.javaClass).invoke(pb, mix)
        val policy = pbC.getMethod("build").invoke(pb)!!

        val r = am.javaClass.getMethod("registerAudioPolicy", policy.javaClass).invoke(am, policy) as Int
        if (r != 0) throw IllegalStateException("registerAudioPolicy devolvió $r")
        val rec = policy.javaClass.getMethod("createAudioRecordSink", mix.javaClass).invoke(policy, mix) as AudioRecord

        val buf = AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT) * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
            .setAudioFormat(fmt).setBufferSizeInBytes(buf).setTransferMode(AudioTrack.MODE_STREAM).build()

        Thread {
            try {
                var last = -2
                val pcm = ShortArray(2048)
                rec.startRecording(); track.play()
                while (w.run) {
                    if (w.dev != last) {
                        last = w.dev
                        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.id == last }
                            ?.let { track.setPreferredDevice(it) }
                    }
                    val n = rec.read(pcm, 0, pcm.size)
                    if (n > 0) {
                        val g = w.vol
                        for (i in 0 until n) pcm[i] = (pcm[i] * g).toInt().coerceIn(-32768, 32767).toShort()
                        track.write(pcm, 0, n)
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { rec.stop(); rec.release(); track.stop(); track.release() } catch (_: Throwable) {}
                try {
                    val m = am.javaClass.methods.first { it.name.startsWith("unregisterAudioPolicy") && it.parameterTypes.size == 1 }
                    m.invoke(am, policy)
                } catch (_: Throwable) {}
            }
        }.start()
    }
}
