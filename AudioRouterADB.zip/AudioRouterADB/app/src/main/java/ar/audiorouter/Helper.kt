package ar.audiorouter

import android.content.Context
import android.media.*
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket

/**
 * Corre como usuario "shell" (uid 2000), lanzado por ADB inalámbrico. Usa APIs @SystemApi por reflexión.
 *  - Salida por app: AudioPolicy con una "mix" RENDER por UID (el audio de esa app va directo al dispositivo elegido).
 *  - Volumen por app: PlayerProxy.setVolume() sobre los reproductores activos de esa app.
 *  - Micrófono: setPreferredDeviceForCapturePreset().
 * No copia audio, así que casi no gasta RAM ni CPU.
 */
object Helper {
    private lateinit var token: String
    private lateinit var ctx: Context
    private lateinit var am: AudioManager
    private val workers = HashMap<Int, W>()
    private val INT = Int::class.javaPrimitiveType
    @Volatile private var micOn = false
    @Volatile private var lastUse = System.currentTimeMillis()

    class W(val uid: Int, @Volatile var dev: Int, @Volatile var vol: Float) {
        var policy: Any? = null
        @Volatile var touched = false
    }

    private fun log(s: String) = System.err.println("arhelper: $s")

    @JvmStatic
    fun main(args: Array<String>) {
        try {
            try {
                val ps = java.io.PrintStream(java.io.FileOutputStream("/data/local/tmp/arhelper.log", true), true)
                System.setErr(ps); System.setOut(ps)
            } catch (_: Throwable) {}
            token = args.getOrNull(0) ?: ""
            log("iniciando uid=${android.os.Process.myUid()}")
            Looper.prepareMainLooper()
            ctx = makeContext()
            log("contexto ok (${ctx.packageName})")
            am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            Thread { serve() }.start()
            Thread { volumeLoop() }.start()
            // Se cierra solo tras 10 min sin uso (sin apps ruteadas ni micrófono fijado): libera RAM.
            Thread {
                while (true) {
                    Thread.sleep(60_000)
                    val idle = synchronized(workers) { workers.isEmpty() } && !micOn &&
                        System.currentTimeMillis() - lastUse > 10 * 60_000
                    if (idle) System.exit(0)
                }
            }.start()
            Looper.loop()
        } catch (t: Throwable) {
            System.err.println("arhelper: FALLÓ al iniciar")
            t.printStackTrace()
            System.exit(1)
        }
    }

    private fun makeContext(): Context {
        val at = Class.forName("android.app.ActivityThread")
        try {
            val sys = at.getMethod("systemMain").invoke(null)
            return at.getMethod("getSystemContext").invoke(sys) as Context
        } catch (e: Throwable) {
            log("systemMain falló (${e.cause ?: e}); pruebo el constructor")
            val c = at.getDeclaredConstructor(); c.isAccessible = true
            return at.getMethod("getSystemContext").invoke(c.newInstance()) as Context
        }
    }

    private fun serve() {
        val ss = try { ServerSocket(HelperClient.PORT, 5, InetAddress.getByName("127.0.0.1")) }
        catch (t: Throwable) { log("no pude abrir el puerto: $t"); System.exit(1); return }
        log("escuchando en ${HelperClient.PORT}")
        while (true) {
            val s = ss.accept()
            try {
                val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: ""
                val parts = line.trim().split(" ", limit = 2)
                val r = if (parts[0] != token || parts.size < 2) "ERR token"
                else try { handle(parts[1]) } catch (e: Throwable) {
                    val m = e.cause ?: e
                    log("error en '${parts[1]}': $m"); m.printStackTrace()
                    "ERR ${m.message ?: m.javaClass.simpleName}"
                }
                s.getOutputStream().apply { write("$r\n".toByteArray()); flush() }
            } catch (_: Exception) {}
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun handle(cmd: String): String {
        lastUse = System.currentTimeMillis()
        val p = cmd.split(" ")
        return when (p[0]) {
            "PING" -> "OK uid=${android.os.Process.myUid()}"
            "QUIT" -> { Thread { Thread.sleep(200); System.exit(0) }.start(); "OK" }
            "CHECK" -> { am.javaClass.getMethod("getPreferredDevicesForCapturePreset", INT).invoke(am, 1); "OK" }
            "MIC" -> mic(true)
            "MICOFF" -> mic(false)
            "SET" -> set(p[1].toInt(), p[2].toInt(), p[3].toFloat())
            "DEL" -> del(p[1].toInt())
            "STATUS" -> status()
            else -> "ERR comando desconocido"
        }
    }

    // ------------------------------------------------------------ micrófono
    private fun mic(on: Boolean): String {
        val ada = Class.forName("android.media.AudioDeviceAttributes")
        val builtin = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            .first { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
        val attr = ada.getConstructor(AudioDeviceInfo::class.java).newInstance(builtin)
        val res = listOf(1, 5, 6, 7, 9, 10).map { pr ->
            try {
                if (on) am.javaClass.getMethod("setPreferredDeviceForCapturePreset", INT, ada).invoke(am, pr, attr)
                else am.javaClass.getMethod("clearPreferredDevicesForCapturePreset", INT).invoke(am, pr)
            } catch (e: Throwable) { "err:${e.cause?.message}" }
        }
        log("MIC on=$on -> $res")
        if (res.all { it is String && it.startsWith("err:") }) return "ERR ${res.first()}"
        micOn = on
        val back = try {
            (am.javaClass.getMethod("getPreferredDevicesForCapturePreset", INT).invoke(am, 7) as List<*>).size
        } catch (_: Throwable) { -1 }
        return "OK $res leidos=$back"
    }

    // ------------------------------------------------------------ salida y volumen por app
    private fun set(uid: Int, dev: Int, vol: Float): String = synchronized(workers) {
        val w = workers[uid]
        if (w == null) {
            val nw = W(uid, dev, vol)
            register(nw)
            workers[uid] = nw
            log("ruta registrada uid=$uid dispositivo=$dev vol=$vol")
        } else {
            w.vol = vol
            if (w.dev != dev) {
                unregister(w.policy); w.policy = null
                w.dev = dev
                register(w)
                log("ruta cambiada uid=$uid dispositivo=$dev")
            }
        }
        "OK"
    }

    private fun del(uid: Int): String = synchronized(workers) {
        workers.remove(uid)?.let {
            unregister(it.policy)
            it.vol = 1f; it.touched = true; workers[uid] = it          // la loop de volumen restaura 100 %
            Thread { Thread.sleep(1500); synchronized(workers) { workers.remove(uid) } }.start()
        }
        "OK"
    }

    private fun register(w: W) {
        val info = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.id == w.dev }
            ?: throw IllegalStateException("la salida ${w.dev} ya no está disponible")
        val rate = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()

        val rbC = Class.forName("android.media.audiopolicy.AudioMixingRule\$Builder")
        val rb = rbC.getConstructor().newInstance()
        rbC.getMethod("addMixRule", INT, Any::class.java).invoke(rb, 4 /* RULE_MATCH_UID */, w.uid)
        val rule = rbC.getMethod("build").invoke(rb)!!

        val mbC = Class.forName("android.media.audiopolicy.AudioMix\$Builder")
        val mb = mbC.getConstructor(rule.javaClass).newInstance(rule)
        mbC.getMethod("setFormat", AudioFormat::class.java).invoke(mb, fmt)
        mbC.getMethod("setRouteFlags", INT).invoke(mb, 1 /* ROUTE_FLAG_RENDER */)
        mbC.getMethod("setDevice", AudioDeviceInfo::class.java).invoke(mb, info)
        val mix = mbC.getMethod("build").invoke(mb)!!

        val pbC = Class.forName("android.media.audiopolicy.AudioPolicy\$Builder")
        val pb = pbC.getConstructor(Context::class.java).newInstance(ctx)
        pbC.getMethod("setLooper", Looper::class.java).invoke(pb, Looper.getMainLooper())
        pbC.getMethod("addMix", mix.javaClass).invoke(pb, mix)
        val policy = pbC.getMethod("build").invoke(pb)!!

        val r = am.javaClass.getMethod("registerAudioPolicy", policy.javaClass).invoke(am, policy) as Int
        if (r != 0) throw IllegalStateException("registerAudioPolicy devolvió $r")
        w.policy = policy
    }

    private fun unregister(policy: Any?) {
        if (policy == null) return
        try {
            val m = am.javaClass.methods.first { it.name.startsWith("unregisterAudioPolicy") && it.parameterTypes.size == 1 }
            m.invoke(am, policy)
        } catch (t: Throwable) { log("unregister: ${t.cause ?: t}") }
    }

    private fun uidOf(c: Any): Int = c.javaClass.getMethod("getClientUid").invoke(c) as Int

    private fun volumeLoop() {
        var lastErr = ""
        while (true) {
            try {
                Thread.sleep(700)
                val ws = synchronized(workers) { workers.values.toList() }
                if (ws.isEmpty()) continue
                for (c in am.activePlaybackConfigurations) {
                    val w = ws.firstOrNull { it.uid == uidOf(c) } ?: continue
                    val v = w.vol.coerceIn(0f, 1f)
                    if (v < 0.999f || w.touched) {
                        val px = c.javaClass.getMethod("getPlayerProxy").invoke(c) ?: continue
                        px.javaClass.getMethod("setVolume", Float::class.javaPrimitiveType).invoke(px, v)
                    }
                }
                ws.forEach { it.touched = it.vol < 0.999f }
            } catch (t: Throwable) {
                val m = "${t.cause ?: t}"
                if (m != lastErr) { lastErr = m; log("volumen: $m") }
            }
        }
    }

    /** uid:cantidad_de_reproductores_activos:id_de_salida_actual ; ... */
    private fun status(): String {
        val ws = synchronized(workers) { workers.values.toList() }
        val cfgs = try { am.activePlaybackConfigurations } catch (_: Throwable) { emptyList() }
        return "OK " + ws.joinToString(";") { w ->
            val mine = cfgs.filter { uidOf(it) == w.uid }
            val dev = mine.firstNotNullOfOrNull { c ->
                try { (c.javaClass.getMethod("getAudioDeviceInfo").invoke(c) as? AudioDeviceInfo)?.id } catch (_: Throwable) { null }
            } ?: -1
            "${w.uid}:${mine.size}:$dev"
        }
    }
}
