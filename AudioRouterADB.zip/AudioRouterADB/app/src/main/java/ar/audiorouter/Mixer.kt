package ar.audiorouter

import java.util.concurrent.CopyOnWriteArrayList

/** Estado compartido entre la pantalla y el servicio. */
object Mixer {
    class Cfg(val uid: Int, val label: String) {
        @Volatile var deviceId: Int = -1      // id de AudioDeviceInfo de salida
        @Volatile var volume: Float = 1f      // 0.0 .. 1.0
        var pkg: String = ""
        var wantType: Int = -1                // salida elegida (tipo + dirección): sobrevive a reconexiones
        var wantAddr: String = ""
    }
    val cfgs = CopyOnWriteArrayList<Cfg>()
    @Volatile var running = false
    @Volatile var error: String? = null
}
