package ar.audiorouter

import java.util.concurrent.CopyOnWriteArrayList

/** Estado compartido entre la pantalla y el servicio. */
object Mixer {
    class Cfg(val uid: Int, val label: String) {
        @Volatile var deviceId: Int = -1      // id de AudioDeviceInfo de salida
        @Volatile var volume: Float = 1f      // 0.0 .. 1.5
    }
    val cfgs = CopyOnWriteArrayList<Cfg>()
    @Volatile var running = false
    @Volatile var error: String? = null
}
