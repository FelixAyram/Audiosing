package ar.audiorouter

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Captura el audio (por UID) de cada app elegida con AudioPlaybackCapture
 * y lo vuelve a reproducir en la salida elegida, con volumen propio.
 */
@Suppress("DEPRECATION")
class MixerService : Service() {

    private var projection: MediaProjection? = null
    @Volatile private var active = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("mixer", "Mezclador de audio", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "mixer")
            .setContentTitle("Audio Router activo")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        // Android 14: hay que declarar el tipo mediaProjection al iniciar el servicio en primer plano
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        // Android 14: el callback se registra ANTES de capturar
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))
        projection = p

        active = true
        Mixer.running = true
        Mixer.error = null
        Mixer.cfgs.forEach { cfg -> Thread { pump(p, cfg) }.start() }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun pump(p: MediaProjection, cfg: Mixer.Cfg) {
        try {
            val am = getSystemService(AudioManager::class.java)
            val rate = 44100
            val capture = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .addMatchingUid(cfg.uid)
                .build()
            val buf = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT) * 4
            val rec = AudioRecord.Builder()
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
                .setBufferSizeInBytes(buf)
                .setAudioPlaybackCaptureConfig(capture)
                .build()
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(buf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            var lastDev = -2
            val pcm = ShortArray(2048)
            rec.startRecording()
            track.play()
            while (active) {
                if (cfg.deviceId != lastDev) {               // cambio de salida en vivo
                    lastDev = cfg.deviceId
                    am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                        .firstOrNull { it.id == lastDev }
                        ?.let { track.setPreferredDevice(it) }
                }
                val n = rec.read(pcm, 0, pcm.size)
                if (n > 0) {
                    val g = cfg.volume                        // volumen propio de la app
                    for (i in 0 until n) pcm[i] = (pcm[i] * g).toInt().coerceIn(-32768, 32767).toShort()
                    track.write(pcm, 0, n)
                }
            }
            rec.stop(); rec.release()
            track.stop(); track.release()
        } catch (e: Exception) {
            Mixer.error = "${cfg.label}: ${e.message}"
        }
    }

    override fun onDestroy() {
        active = false
        Mixer.running = false
        projection?.stop()
        super.onDestroy()
    }
}
