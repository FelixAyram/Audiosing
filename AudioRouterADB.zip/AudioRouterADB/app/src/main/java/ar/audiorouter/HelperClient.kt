package ar.audiorouter

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/** Habla con el ayudante que corre como usuario "shell" (arrancado por ADB inalámbrico). */
object HelperClient {
    const val PORT = 27183
    @Volatile var token = ""

    fun send(cmd: String): String = try {
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", PORT), 800)
            s.soTimeout = 5000
            s.getOutputStream().apply { write("$token $cmd\n".toByteArray()); flush() }
            BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: "ERR sin respuesta"
        }
    } catch (e: Exception) { "ERR ${e.message}" }

    fun alive() = send("PING").startsWith("OK")

    const val LOG = "/data/local/tmp/arhelper.log"

    private fun launch(adb: Adb, ctx: Context, detached: Boolean): Boolean {
        val cp = "CLASSPATH=\$(pm path ${ctx.packageName} | head -1 | cut -d: -f2)"
        val app = "app_process /system/bin ar.audiorouter.Helper $token </dev/null"
        val cmd = if (detached) "rm -f $LOG; $cp setsid nohup $app >>$LOG 2>&1 &"
                  else "$cp $app >>$LOG 2>&1"          // queda atado a la conexión ADB
        Thread { try { adb.sh(cmd) } catch (_: Throwable) {} }.start()
        repeat(28) { Thread.sleep(250); if (alive()) return true }   // ~7 s
        return false
    }

    fun logs(adb: Adb): String = try {
        adb.sh("tail -30 $LOG 2>&1; echo ---logcat---; " +
            "logcat -d -t 600 2>&1 | grep -iE 'arhelper|AndroidRuntime|FATAL|ar.audiorouter' | tail -25").trim()
    } catch (e: Exception) { "no pude leer el registro: ${e.message}" }

    fun start(ctx: Context): String {
        val adb = Adb.get(ctx)
        if (!adb.isConnected) { try { adb.connectTls(ctx.applicationContext, 8000) } catch (_: Throwable) {} }
        if (!adb.isConnected) return "ERR Sin conexión ADB. Primero emparejá."
        // Evita que el ahorro de batería de Android mate la app o el ayudante (si el celu lo permite).
        try { adb.sh("cmd deviceidle whitelist +${ctx.packageName}; cmd appops set ${ctx.packageName} RUN_ANY_IN_BACKGROUND allow") }
        catch (_: Throwable) {}
        if (alive()) { send("QUIT"); Thread.sleep(800) }
        val ok = launch(adb, ctx, true) || launch(adb, ctx, false)
        if (ok) {
            val c = send("CHECK")
            return if (c.startsWith("OK")) "OK Modo ADB activo. Ya podés usar el micrófono y las apps."
            else "ERR El ayudante corre pero Android no le da permiso de audio: ${c.removePrefix("ERR ")}"
        }
        return "ERR El ayudante no arrancó (probé 2 formas).\n" + logs(adb)
    }
}
