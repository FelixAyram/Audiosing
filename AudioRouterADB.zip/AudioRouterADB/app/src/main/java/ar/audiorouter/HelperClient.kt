package ar.audiorouter

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/** Habla con el ayudante que corre como usuario "shell" (arrancado por ADB inalámbrico). */
object HelperClient {
    const val PORT = 27183
    @Volatile var token = ""

    fun send(cmd: String): String = try {
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", PORT), 800)
            s.soTimeout = 5000
            s.getOutputStream().apply { write("$token $cmd\n".toByteArray()); flush() }
            BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: "ERR sin respuesta"
        }
    } catch (e: Exception) { "ERR ${e.message}" }

    fun alive() = send("PING").startsWith("OK")

    fun start(ctx: Context): String {
        val adb = Adb.get(ctx)
        if (!adb.isConnected) adb.connectTls(ctx.applicationContext, 8000)
        if (!adb.isConnected) return "ERR Sin conexión ADB. Primero emparejá (paso 1)."
        if (alive()) { send("QUIT"); Thread.sleep(600) }
        adb.sh("CLASSPATH=\$(pm path ${ctx.packageName} | head -1 | cut -d: -f2) " +
            "nohup app_process /system/bin ar.audiorouter.Helper $token " +
            "</dev/null >/data/local/tmp/arhelper.log 2>&1 &")
        repeat(24) {
            Thread.sleep(250)
            if (alive()) {
                val c = send("CHECK")
                return if (c.startsWith("OK")) "OK Modo ADB activo (permiso de audio concedido a shell)"
                else "ERR El ayudante corre pero Android no le da permiso de audio: ${c.removePrefix("ERR ")}"
            }
        }
        return "ERR El ayudante no arrancó: " + try { adb.sh("tail -6 /data/local/tmp/arhelper.log") } catch (e: Exception) { e.message }
    }
}
