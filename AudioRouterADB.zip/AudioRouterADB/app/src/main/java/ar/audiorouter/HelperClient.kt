package ar.audiorouter

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/** Habla con el ayudante que corre como usuario "shell" (arrancado por ADB inalámbrico). */
object HelperClient {
    const val PORT = 27183
    @Volatile var token = ""

    fun send(cmd: String): String = try {
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", PORT), 800)
            s.soTimeout = 5000
            s.getOutputStream().apply { write("$token $cmd\n".toByteArray()); flush() }
            BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: "ERR sin respuesta"
        }
    } catch (e: Exception) { "ERR ${e.message}" }

    fun alive() = send("PING").startsWith("OK")

    const val LOG = "/data/local/tmp/arhelper.log"

    fun start(ctx: Context): String {
        val adb = Adb.get(ctx)
        if (!adb.isConnected) { try { adb.connectTls(ctx.applicationContext, 8000) } catch (_: Throwable) {} }
        if (!adb.isConnected) return "ERR Sin conexión ADB. Primero emparejá."
        if (alive()) { send("QUIT"); Thread.sleep(800) }
        // En un hilo aparte: si el shell tardara en cerrar, no se cuelga la app.
        Thread {
            try {
                adb.sh("rm -f $LOG; CLASSPATH=\$(pm path ${ctx.packageName} | head -1 | cut -d: -f2) " +
                    "nohup app_process /system/bin ar.audiorouter.Helper $token " +
                    "</dev/null >$LOG 2>&1 &")
            } catch (_: Throwable) {}
        }.start()
        repeat(48) {                                  // hasta ~12 s
            Thread.sleep(250)
            if (alive()) {
                val c = send("CHECK")
                return if (c.startsWith("OK")) "OK Modo ADB activo. Ya podés usar el micrófono y las apps."
                else "ERR El ayudante corre pero Android no le da permiso de audio: ${c.removePrefix("ERR ")}"
            }
        }
        val tail = try { adb.sh("tail -12 $LOG 2>&1").trim() } catch (e: Exception) { e.message }
        return "ERR El ayudante no arrancó. Tocá “Ver registro”.\n$tail"
    }
}
