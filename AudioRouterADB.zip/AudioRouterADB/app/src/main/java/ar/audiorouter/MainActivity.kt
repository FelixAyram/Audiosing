package ar.audiorouter

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.sqrt

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private val ACC = Color.parseColor("#00796B")
    private val INK = Color.parseColor("#1B1F23")
    private val SUB = Color.parseColor("#5F6B76")
    private val OKC = Color.parseColor("#2E7D32")
    private val BAD = Color.parseColor("#C62828")

    private lateinit var am: AudioManager
    private lateinit var mpm: MediaProjectionManager
    private val ui = Handler(Looper.getMainLooper())

    // estado
    private lateinit var dotAdb: TextView
    private lateinit var txtAdb: TextView
    private lateinit var dotHelper: TextView
    private lateinit var txtHelper: TextView
    private lateinit var tvMsg: TextView
    private lateinit var pairHelp: TextView
    private lateinit var mainBtn: Button
    private lateinit var stopBtn: Button
    @Volatile private var helperOn = false
    @Volatile private var autoTried = false

    // micrófono
    private lateinit var micSwitch: Switch
    private var ignoreSwitch = false
    private lateinit var inSpinner: Spinner
    private lateinit var testBtn: Button
    private lateinit var micStatus: TextView
    private lateinit var level: ProgressBar
    private var inputs: List<AudioDeviceInfo> = emptyList()
    @Volatile private var micRunning = false
    private var micThread: Thread? = null

    // apps
    private lateinit var rowsBox: LinearLayout
    private lateinit var modeText: TextView
    private lateinit var captureBtn: Button
    private var outputs: List<AudioDeviceInfo> = emptyList()
    private val rows = mutableListOf<Pair<Mixer.Cfg, Spinner>>()
    private val statusViews = HashMap<Int, TextView>()
    private val poll: Runnable = object : Runnable {
        override fun run() {
            if (helperOn && Mixer.cfgs.isNotEmpty()) Thread {
                val r = HelperClient.send("STATUS")
                if (r.startsWith("OK")) ui.post { applyStatus(r.removePrefix("OK").trim()) }
            }.start()
            ui.postDelayed(this, 2500)
        }
    }

    // ------------------------------------------------------------ helpers de interfaz
    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()
    private fun tv(t: String, size: Float = 15f, color: Int = INK, bold: Boolean = false): TextView = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun lp(top: Int = 0, w: Int = -1): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, -2).apply { topMargin = dp(top) }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat() }
        elevation = dp(2).toFloat()
    }
    private fun pill(t: String, filled: Boolean, f: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; textSize = 15f
        setTextColor(if (filled) Color.WHITE else ACC)
        stateListAnimator = null
        background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            if (filled) setColor(ACC) else { setColor(Color.TRANSPARENT); setStroke(dp(1), ACC) }
        }
        minimumHeight = dp(48)
        setOnClickListener { f() }
    }
    private fun row(vararg v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        v.forEach { addView(it) }
    }
    private fun enable(v: View, on: Boolean) { v.isEnabled = on; v.alpha = if (on) 1f else 0.4f }
    private fun say(t: String): Boolean = ui.post { tvMsg.text = t }
    private fun bg(f: () -> Unit): Unit = Thread {
        try { f() } catch (e: Throwable) { say(friendly("ERR ${e.message}")) }
    }.start()
    private fun friendly(e: String): String = when {
        "ECONNREFUSED" in e || "failed to connect" in e -> "El ayudante está apagado. Tocá “Activar modo ADB”."
        else -> e.removePrefix("ERR ")
    }

    // ------------------------------------------------------------ pantalla
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val sp = getSharedPreferences("p", 0)
        var tok = sp.getString("tok", null)
        if (tok == null) { tok = java.util.UUID.randomUUID().toString().replace("-", ""); sp.edit().putString("tok", tok).apply() }
        HelperClient.token = tok

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(24)) }

        // ===== Estado
        val st = card()
        dotAdb = tv("●", 16f, BAD); txtAdb = tv("ADB inalámbrico: sin conexión")
        dotHelper = tv("●", 16f, BAD); txtHelper = tv("Ayudante: apagado")
        st.addView(tv("Estado", 20f, INK, true))
        st.addView(row(dotAdb.apply { setPadding(0, 0, dp(8), 0) }, txtAdb), lp(8))
        st.addView(row(dotHelper.apply { setPadding(0, 0, dp(8), 0) }, txtHelper), lp(4))
        tvMsg = tv("", 14f, SUB); st.addView(tvMsg, lp(8))
        pairHelp = tv("Falta emparejar (una sola vez):\n" +
            "1. Activá Opciones de desarrollador › Depuración inalámbrica (con Wi-Fi conectado).\n" +
            "2. Tocá “Emparejar” abajo.\n" +
            "3. En Ajustes elegí “Vincular dispositivo con código”.\n" +
            "4. En la notificación de Audio Router escribí el código de 6 dígitos.\n" +
            "5. Volvé acá y tocá “Activar modo ADB”.", 14f, BAD).apply { visibility = View.GONE }
        st.addView(pairHelp, lp(8))
        mainBtn = pill("Activar modo ADB", true) { activate() }
        st.addView(mainBtn, lp(12))
        st.addView(row(
            pill("Emparejar", false) { pair() }.also { it.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) } },
            pill("Detener", false) { stopHelper() }.also { stopBtn = it; it.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) } }
        ), lp(8))
        st.addView(pill("Ver registro (para diagnosticar)", false) { showLog() }, lp(8))
        root.addView(st)

        // ===== Micrófono
        val mc = card()
        mc.addView(tv("Micrófono", 20f, INK, true))
        micSwitch = Switch(this).apply {
            text = "Usar el micrófono del celu en todas las apps"; textSize = 15f
            setOnCheckedChangeListener { _, on -> if (!ignoreSwitch) setMic(on) }
        }
        mc.addView(micSwitch, lp(8))
        mc.addView(tv("El auricular Bluetooth queda solo para escuchar. Requiere modo ADB.", 13f, SUB), lp(4))
        mc.addView(pill("Verificar qué micrófono usan las apps", false) { verifyMic() }, lp(8))
        mc.addView(tv("Conectá el auricular Bluetooth antes de verificar. Debe decir “Micrófono del celu”.", 12f, SUB), lp(4))
        mc.addView(tv("Probar una entrada (solo dentro de esta app)", 13f, SUB), lp(16))
        inSpinner = Spinner(this); mc.addView(inSpinner, lp(0))
        testBtn = pill("Probar", false) { if (micRunning) stopMic() else startMic() }
        mc.addView(testBtn, lp(4))
        level = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        mc.addView(level, lp(8))
        micStatus = tv("", 13f, SUB); mc.addView(micStatus)
        root.addView(mc, lp(12))

        // ===== Apps
        val ac = card()
        ac.addView(tv("Apps: salida y volumen", 20f, INK, true))
        modeText = tv("", 13f, SUB); ac.addView(modeText, lp(4))
        ac.addView(pill("＋ Agregar app", true) { pickApp() }, lp(12))
        rowsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ac.addView(rowsBox)
        captureBtn = pill("Modo captura (sin ADB, experimental)", false) { toggleMixer() }
        ac.addView(captureBtn, lp(12))
        root.addView(ac, lp(12))

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#F2F4F5")); addView(root) })

        am.registerAudioDeviceCallback(object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(a: Array<out AudioDeviceInfo>?) = refreshDevices()
            override fun onAudioDevicesRemoved(r: Array<out AudioDeviceInfo>?) = refreshDevices()
        }, null)
        refreshDevices(); updateMode(); askPermissions()
    }

    override fun onResume() { super.onResume(); refreshStatus(); ui.removeCallbacks(poll); ui.postDelayed(poll, 1500) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(poll) }

    private fun applyStatus(s: String) {
        val seen = HashSet<Int>()
        for (e in s.split(";").filter { it.isNotBlank() }) {
            val f = e.split(":"); if (f.size < 3) continue
            val uid = f[0].toInt(); val n = f[1].toInt(); val dev = f[2].toInt()
            seen += uid
            val tvx = statusViews[uid] ?: continue
            val name = outputs.firstOrNull { it.id == dev }?.let { nameOf(it) } ?: "—"
            if (n == 0) { tvx.text = "✔ Lista. Sin audio activo ahora: pausá y volvé a reproducir en la app."; tvx.setTextColor(SUB) }
            else { tvx.text = "▶ Reproduciendo ($n) · sale por: $name"; tvx.setTextColor(OKC) }
        }
        for ((uid, tvx) in statusViews) if (uid !in seen) { tvx.text = "Esperando al ayudante…"; tvx.setTextColor(SUB) }
    }

    private fun refreshStatus(): Unit = Thread {
        val up = Adb.isUp()
        val alive = HelperClient.alive()
        val perm = alive && HelperClient.send("CHECK").startsWith("OK")
        helperOn = alive && perm
        if (up && !alive && !autoTried) {          // ya emparejado: arrancar el ayudante solo
            autoTried = true
            ui.post { tvMsg.text = "ADB conectado ✔ Iniciando el ayudante…"; activate() }
        }
        ui.post {
            if (up) pairHelp.visibility = View.GONE
            dotAdb.setTextColor(if (up) OKC else BAD)
            txtAdb.text = "ADB inalámbrico: " + if (up) "conectado" else "sin conexión"
            dotHelper.setTextColor(if (helperOn) OKC else BAD)
            txtHelper.text = "Ayudante: " + when {
                helperOn -> "activo, con permiso de audio"
                alive -> "activo, pero Android no le da permiso de audio"
                else -> "apagado"
            }
            mainBtn.text = if (alive) "Reiniciar modo ADB" else "Activar modo ADB"
            enable(micSwitch, helperOn); enable(stopBtn, alive)
            updateMode()
        }
    }.start()

    private fun updateMode() {
        modeText.text = if (helperOn)
            "Modo ADB activo. Elegí la salida y el volumen (0–100 %) de cada app. Si recién cambiaste la salida, pausá y volvé a reproducir en esa app."
        else "Activá el modo ADB para que el audio salga solo por la salida elegida."
        captureBtn.visibility = if (helperOn) View.GONE else View.VISIBLE
    }

    // ------------------------------------------------------------ ADB
    private fun pair() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            tvMsg.text = "Permití las notificaciones de Audio Router (Ajustes › Apps › Audio Router › Notificaciones): ahí se escribe el código."
            askPermissions(); return
        }
        startForegroundService(Intent(this, PairService::class.java))
        tvMsg.text = "Abrí “Vincular dispositivo con código” y respondé la notificación con el código."
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (_: Exception) {}
    }

    private fun activate(): Unit = bg {
        ui.post { enable(mainBtn, false) }
        say("Conectando por ADB inalámbrico…")
        val adb = Adb.get(this)
        if (!adb.isConnected) { try { adb.connectTls(applicationContext, 8000) } catch (_: Throwable) {} }
        if (!adb.isConnected) {
            say("No se pudo conectar. Revisá que la Depuración inalámbrica esté activa y que ya hayas emparejado.")
            ui.post { pairHelp.visibility = View.VISIBLE; enable(mainBtn, true) }
            refreshStatus(); return@bg
        }
        say("Iniciando ayudante…")
        val r = HelperClient.start(this)
        say(r.removePrefix("OK ").removePrefix("ERR "))
        ui.post { enable(mainBtn, true) }
        refreshStatus()
        Thread.sleep(300)
        ui.post { pushAll() }
    }

    private fun stopHelper(): Unit = bg {
        autoTried = true
        HelperClient.send("MICOFF"); HelperClient.send("QUIT")
        helperOn = false
        ui.post { ignoreSwitch = true; micSwitch.isChecked = false; ignoreSwitch = false }
        say("Ayudante detenido. Todo vuelve al automático.")
        Thread.sleep(500); refreshStatus()
    }

    private fun showLog(): Unit = bg {
        val sb = StringBuilder()
        sb.append("ADB: ").append(if (Adb.isUp()) "conectado" else "sin conexión").append('\n')
        sb.append("Ayudante: ").append(if (HelperClient.alive()) "responde" else "no responde").append('\n')
        sb.append("Modelo: ${Build.MODEL}, Android ${Build.VERSION.RELEASE}\n")
        if (Adb.isUp()) {
            val adb = Adb.get(this)
            sb.append("\n[permisos de shell]\n")
                .append(adb.sh("dumpsys package com.android.shell | grep -E 'MODIFY_AUDIO_ROUTING|MANAGE_AUDIO_POLICY'").trim().take(500))
            sb.append("\n\n[registro del ayudante]\n").append(HelperClient.logs(adb))
            sb.append("\n\n[procesos]\n").append(adb.sh("ps -A | grep app_process").trim())
        }
        val txt = sb.toString()
        ui.post {
            val t = TextView(this).apply {
                text = txt; textSize = 12f; typeface = Typeface.MONOSPACE
                setTextIsSelectable(true); setPadding(dp(16), dp(8), dp(16), dp(8))
            }
            AlertDialog.Builder(this).setTitle("Registro").setView(ScrollView(this).apply { addView(t) })
                .setPositiveButton("Copiar") { _, _ ->
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("registro", txt))
                    Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
                }.setNegativeButton("Cerrar", null).show()
        }
    }

    @SuppressLint("MissingPermission")
    private fun verifyMic(): Unit = bg {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ui.post { askPermissions() }; return@bg
        }
        val sb = StringBuilder()
        val tests = listOf("Llamadas y videollamadas" to MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                           "Notas de voz y otras apps" to MediaRecorder.AudioSource.MIC)
        for ((label, src) in tests) {
            try {
                val ar = AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 4096)
                ar.startRecording(); Thread.sleep(800)
                sb.append("$label → ${ar.routedDevice?.let { nameOf(it) } ?: "?"}\n")
                ar.stop(); ar.release()
            } catch (e: Exception) { sb.append("$label → error ${e.message}\n") }
        }
        ui.post { micStatus.text = sb.toString().trim() }
    }

    private fun setMic(on: Boolean): Unit = bg {
        val r = HelperClient.send(if (on) "MIC" else "MICOFF")
        if (r.startsWith("OK")) say(if (on) "Micrófono del celu fijado para todas las apps." else "Micrófono en automático.")
        else { say(friendly(r)); ui.post { ignoreSwitch = true; micSwitch.isChecked = !on; ignoreSwitch = false } }
    }

    private fun push(c: Mixer.Cfg) {
        if (!helperOn) return
        Thread {
            val r = HelperClient.send("SET ${c.uid} ${c.deviceId} ${c.volume}")
            if (r.startsWith("ERR")) {
                val msg = friendly(r)
                ui.post {
                    statusViews[c.uid]?.apply { text = "✖ $msg"; setTextColor(BAD) }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
    private fun pushAll(): Unit = Mixer.cfgs.forEach { push(it) }

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) p += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        val missing = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refreshDevices()
    }

    // ------------------------------------------------------------ dispositivos
    private fun nameOf(d: AudioDeviceInfo): String {
        val t = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Micrófono del celu"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Parlante del celu"
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Auricular de llamada"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (llamadas)"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (música)"
            AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE"
            AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Parlante Bluetooth LE"
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Auriculares con cable"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            AudioDeviceInfo.TYPE_HEARING_AID -> "Audífono"
            else -> "Otro (${d.type})"
        }
        return "$t · ${d.productName}"
    }

    private val outTypes = setOf(
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_EARPIECE,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLE_SPEAKER, AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_HEARING_AID)

    private fun refreshDevices() {
        val selIn = inputs.getOrNull(inSpinner.selectedItemPosition)?.id
        inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        inSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, inputs.map { nameOf(it) })
        inputs.indexOfFirst { it.id == selIn }.takeIf { it >= 0 }?.let { inSpinner.setSelection(it) }

        outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in outTypes }
        for ((cfg, sp) in rows) {
            val cur = cfg.deviceId
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, outputs.map { nameOf(it) })
            outputs.indexOfFirst { it.id == cur }.takeIf { it >= 0 }?.let { sp.setSelection(it) }
        }
    }

    // ------------------------------------------------------------ prueba de micrófono
    private fun isBt(d: AudioDeviceInfo) =
        d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || d.type == AudioDeviceInfo.TYPE_BLE_HEADSET

    @SuppressLint("MissingPermission")
    private fun startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { askPermissions(); return }
        val dev = inputs.getOrNull(inSpinner.selectedItemPosition) ?: return
        val bt = isBt(dev)
        if (bt) {
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            if (Build.VERSION.SDK_INT >= 31) {
                am.availableCommunicationDevices.firstOrNull { it.id == dev.id }?.let { am.setCommunicationDevice(it) }
            } else { am.startBluetoothSco(); am.isBluetoothScoOn = true }
        }
        micRunning = true; testBtn.text = "Parar prueba"
        micThread = Thread {
            try {
                if (bt) Thread.sleep(800)
                val rate = 16000
                val buf = maxOf(AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096)
                val ar = AudioRecord(
                    if (bt) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC,
                    rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf)
                val ok = ar.setPreferredDevice(dev)
                ar.startRecording()
                val routed = ar.routedDevice
                ui.post {
                    micStatus.text = "Pedida: ${nameOf(dev)} (${if (ok) "ok" else "no aceptada"})\n" +
                        "En uso: ${routed?.let { nameOf(it) } ?: "?"}"
                }
                val d = ShortArray(1024)
                while (micRunning) {
                    val n = ar.read(d, 0, d.size)
                    if (n > 0) {
                        var s = 0.0
                        for (i in 0 until n) s += d[i].toDouble() * d[i]
                        val v = (sqrt(s / n) / 32768.0 * 400).toInt().coerceIn(0, 100)
                        ui.post { level.progress = v }
                    }
                }
                ar.stop(); ar.release()
            } catch (e: Exception) {
                ui.post { micStatus.text = "Error: ${e.message}"; micRunning = false; testBtn.text = "Probar" }
            }
        }.also { it.start() }
    }

    private fun stopMic() {
        micRunning = false
        micThread?.join(500)
        if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
        else { am.stopBluetoothSco(); am.isBluetoothScoOn = false }
        am.mode = AudioManager.MODE_NORMAL
        testBtn.text = "Probar"; level.progress = 0; micStatus.text = "Detenido"
    }

    // ------------------------------------------------------------ apps
    private fun pickApp() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0).map { it.activityInfo.applicationInfo }
            .distinctBy { it.uid }.filter { it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val names = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Elegí la app")
            .setItems(names) { _, i -> addRow(apps[i].uid, names[i], pm.getApplicationIcon(apps[i])) }.show()
    }

    private fun addRow(uid: Int, label: String, icon: Drawable) {
        if (Mixer.cfgs.any { it.uid == uid }) return
        val cfg = Mixer.Cfg(uid, label)
        cfg.deviceId = outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }?.id
            ?: outputs.firstOrNull()?.id ?: -1
        Mixer.cfgs.add(cfg)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { setColor(Color.parseColor("#F6F8F9")); cornerRadius = dp(12).toFloat() }
        }
        val ic = ImageView(this).apply { setImageDrawable(icon) }
        val close = tv("✕", 18f, SUB).apply {
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener {
                Mixer.cfgs.remove(cfg); rows.removeAll { it.first === cfg }; statusViews.remove(cfg.uid); rowsBox.removeView(box)
                if (helperOn) Thread { HelperClient.send("DEL ${cfg.uid}") }.start()
            }
        }
        box.addView(row(ic.also { it.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) } },
            tv(label, 17f, INK, true).also { it.layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, close))

        val sp = Spinner(this)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                outputs.getOrNull(pos)?.let { if (cfg.deviceId != it.id) { cfg.deviceId = it.id; push(cfg) } }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(sp, lp(6))

        val volTxt = tv("100%", 14f, SUB)
        val sb = SeekBar(this).apply {
            max = 100; progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    cfg.volume = p / 100f; volTxt.text = "$p%"; if (u) push(cfg)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(row(tv("Volumen", 13f, SUB).also { it.setPadding(0, 0, dp(8), 0) },
            sb.also { it.layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, volTxt), lp(4))

        val st = tv("Esperando al ayudante…", 12f, SUB)
        statusViews[uid] = st
        box.addView(st, lp(6))
        rowsBox.addView(box, lp(10))
        rows += cfg to sp
        refreshDevices()
        push(cfg)
    }

    // ------------------------------------------------------------ modo captura (sin ADB)
    private fun toggleMixer() {
        if (Mixer.running) {
            stopService(Intent(this, MixerService::class.java))
            captureBtn.text = "Modo captura (sin ADB, experimental)"
        } else if (Mixer.cfgs.isEmpty()) {
            Toast.makeText(this, "Agregá al menos una app", Toast.LENGTH_SHORT).show()
        } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askPermissions()
        } else startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 42 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, MixerService::class.java).putExtra("code", res).putExtra("data", data))
            captureBtn.text = "Parar modo captura"
        }
    }

    override fun onDestroy() {
        if (micRunning) stopMic()
        super.onDestroy()
    }
}
