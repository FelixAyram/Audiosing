package ar.audiorouter

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*
import kotlin.math.sqrt

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private lateinit var am: AudioManager
    private lateinit var mpm: MediaProjectionManager
    private val ui = Handler(Looper.getMainLooper())
    private val pad by lazy { (16 * resources.displayMetrics.density).toInt() }

    // ---- ADB
    private lateinit var tvAdb: TextView
    @Volatile private var helperOn = false

    // ---- micrófono (prueba)
    private lateinit var inSpinner: Spinner
    private lateinit var micBtn: Button
    private lateinit var micStatus: TextView
    private lateinit var level: ProgressBar
    private var inputs: List<AudioDeviceInfo> = emptyList()
    @Volatile private var micRunning = false
    private var micThread: Thread? = null

    // ---- apps
    private lateinit var rowsBox: LinearLayout
    private lateinit var mixBtn: Button
    private lateinit var mixStatus: TextView
    private var outputs: List<AudioDeviceInfo> = emptyList()
    private val rows = mutableListOf<Pair<Mixer.Cfg, Spinner>>()

    private fun text(t: String, size: Float) = TextView(this).apply {
        text = t; textSize = size; setPadding(0, pad / 2, 0, pad / 4)
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun say(t: String) = ui.post { tvAdb.text = t }
    private fun bg(f: () -> Unit) = Thread {
        try { f() } catch (e: Throwable) { say("Error: ${e.message}") }
    }.start()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val sp = getSharedPreferences("p", 0)
        var tok = sp.getString("tok", null)
        if (tok == null) { tok = java.util.UUID.randomUUID().toString().replace("-", ""); sp.edit().putString("tok", tok).apply() }
        HelperClient.token = tok

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        // ===== 0) ADB
        root.addView(text("0) Modo ADB (recomendado)", 22f))
        root.addView(text("Con Depuración inalámbrica activa, la app se conecta a sí misma y habilita el control real del audio.", 14f))
        root.addView(btn("1) Emparejar (una sola vez)") {
            startForegroundService(Intent(this, PairService::class.java))
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
            catch (e: Exception) { say("Abrí Ajustes › Opciones de desarrollador › Depuración inalámbrica › Vincular con código.") }
        })
        root.addView(btn("2) Conectar y activar modo ADB") {
            bg {
                say("Conectando…")
                val r = HelperClient.start(this)
                helperOn = r.startsWith("OK")
                say(r)
                ui.post { updateMode(); pushAll() }
            }
        })
        root.addView(btn("Diagnóstico") {
            bg {
                val adb = Adb.get(this)
                if (!adb.isConnected) adb.connectTls(applicationContext, 8000)
                val n = adb.sh("dumpsys package com.android.shell | grep -c MODIFY_AUDIO_ROUTING").trim()
                say("ADB: ${if (adb.isConnected) "conectado" else "sin conexión"}\n" +
                    "'shell' menciona MODIFY_AUDIO_ROUTING: $n vez/veces (0 = no lo tiene)\n" +
                    "Ayudante: ${if (HelperClient.alive()) HelperClient.send("CHECK") else "apagado"}")
            }
        })
        tvAdb = text("ADB: ${if (Adb.isUp()) "conectado" else "sin conexión"}", 14f)
        root.addView(tvAdb)

        // ===== 1) Micrófono
        root.addView(text("1) Micrófono", 22f).apply { setPadding(0, pad * 2, 0, 0) })
        root.addView(btn("Forzar micrófono del celu en TODAS las apps") { bg { say(HelperClient.send("MIC")) } })
        root.addView(btn("Soltar (volver al automático)") { bg { say(HelperClient.send("MICOFF")) } })
        root.addView(text("Prueba de entrada (solo dentro de esta app):", 14f))
        inSpinner = Spinner(this); root.addView(inSpinner)
        micBtn = btn("Probar micrófono") { if (micRunning) stopMic() else startMic() }
        root.addView(micBtn)
        level = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(level)
        micStatus = text("", 14f); root.addView(micStatus)

        // ===== 2) Apps
        root.addView(text("2) Apps: salida y volumen", 22f).apply { setPadding(0, pad * 2, 0, 0) })
        root.addView(btn("＋ Agregar app") { pickApp() })
        rowsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(rowsBox)
        mixBtn = btn("Iniciar mezclador (modo captura)") { toggleMixer() }
        root.addView(mixBtn)
        mixStatus = text("", 13f); root.addView(mixStatus)
        setContentView(ScrollView(this).apply { addView(root) })

        am.registerAudioDeviceCallback(object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(a: Array<out AudioDeviceInfo>?) = refreshDevices()
            override fun onAudioDevicesRemoved(r: Array<out AudioDeviceInfo>?) = refreshDevices()
        }, null)
        refreshDevices(); updateMode(); askPermissions()
    }

    override fun onResume() {
        super.onResume()
        mixBtn.text = if (Mixer.running) "Parar mezclador" else "Iniciar mezclador (modo captura)"
        Thread { helperOn = HelperClient.alive(); ui.post { updateMode() } }.start()
    }

    private fun updateMode() {
        mixStatus.text = if (helperOn)
            "Modo ADB activo: el audio de las apps agregadas sale SOLO por la salida elegida, con su volumen. Los cambios son en vivo."
        else "Sin modo ADB: se usa captura. El audio original sigue sonando además (solo multimedia/juegos)."
    }

    private fun push(c: Mixer.Cfg) {
        if (helperOn) Thread { HelperClient.send("SET ${c.uid} ${c.deviceId} ${c.volume}") }.start()
    }
    private fun pushAll() = Mixer.cfgs.forEach { push(it) }

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) p += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        val missing = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refreshDevices()
    }

    // ------------------------------------------------------------ dispositivos
    private fun nameOf(d: AudioDeviceInfo): String {
        val t = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Micrófono del celu"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Parlante del celu"
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Auricular de llamada del celu"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (llamadas)"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (música)"
            AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE"
            AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Parlante Bluetooth LE"
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Auriculares con cable"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            AudioDeviceInfo.TYPE_HEARING_AID -> "Audífono"
            else -> "Otro (${d.type})"
        }
        return "$t · ${d.productName}"
    }

    private val outTypes = setOf(
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_EARPIECE,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLE_SPEAKER, AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_HEARING_AID)

    private fun refreshDevices() {
        val selIn = inputs.getOrNull(inSpinner.selectedItemPosition)?.id
        inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        inSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, inputs.map { nameOf(it) })
        inputs.indexOfFirst { it.id == selIn }.takeIf { it >= 0 }?.let { inSpinner.setSelection(it) }

        outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in outTypes }
        for ((cfg, sp) in rows) {
            val cur = cfg.deviceId
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, outputs.map { nameOf(it) })
            outputs.indexOfFirst { it.id == cur }.takeIf { it >= 0 }?.let { sp.setSelection(it) }
        }
    }

    // ------------------------------------------------------------ prueba de micrófono
    private fun isBt(d: AudioDeviceInfo) =
        d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || d.type == AudioDeviceInfo.TYPE_BLE_HEADSET

    @SuppressLint("MissingPermission")
    private fun startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { askPermissions(); return }
        val dev = inputs.getOrNull(inSpinner.selectedItemPosition) ?: return
        val bt = isBt(dev)
        if (bt) {
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            if (Build.VERSION.SDK_INT >= 31) {
                am.availableCommunicationDevices.firstOrNull { it.id == dev.id }?.let { am.setCommunicationDevice(it) }
            } else { am.startBluetoothSco(); am.isBluetoothScoOn = true }
        }
        micRunning = true; micBtn.text = "Parar prueba"
        micThread = Thread {
            try {
                if (bt) Thread.sleep(800)
                val rate = 16000
                val buf = maxOf(AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096)
                val ar = AudioRecord(
                    if (bt) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC,
                    rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf)
                val ok = ar.setPreferredDevice(dev)
                ar.startRecording()
                val routed = ar.routedDevice
                ui.post {
                    micStatus.text = "Pedida: ${nameOf(dev)} (${if (ok) "ok" else "no aceptada"})\n" +
                        "En uso: ${routed?.let { nameOf(it) } ?: "?"}"
                }
                val d = ShortArray(1024)
                while (micRunning) {
                    val n = ar.read(d, 0, d.size)
                    if (n > 0) {
                        var s = 0.0
                        for (i in 0 until n) s += d[i].toDouble() * d[i]
                        val v = (sqrt(s / n) / 32768.0 * 400).toInt().coerceIn(0, 100)
                        ui.post { level.progress = v }
                    }
                }
                ar.stop(); ar.release()
            } catch (e: Exception) {
                ui.post { micStatus.text = "Error: ${e.message}"; micRunning = false; micBtn.text = "Probar micrófono" }
            }
        }.also { it.start() }
    }

    private fun stopMic() {
        micRunning = false
        micThread?.join(500)
        if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
        else { am.stopBluetoothSco(); am.isBluetoothScoOn = false }
        am.mode = AudioManager.MODE_NORMAL
        micBtn.text = "Probar micrófono"; level.progress = 0; micStatus.text = "Detenido"
    }

    // ------------------------------------------------------------ apps
    private fun pickApp() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0).map { it.activityInfo.applicationInfo }
            .distinctBy { it.uid }.filter { it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val names = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Elegí la app")
            .setItems(names) { _, i -> addRow(apps[i].uid, names[i]) }.show()
    }

    private fun addRow(uid: Int, label: String) {
        if (Mixer.cfgs.any { it.uid == uid }) return
        val cfg = Mixer.Cfg(uid, label)
        cfg.deviceId = outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }?.id
            ?: outputs.firstOrNull()?.id ?: -1
        Mixer.cfgs.add(cfg)

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, pad, 0, 0) }
        box.addView(text(label, 18f))
        val sp = Spinner(this)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                outputs.getOrNull(pos)?.let { if (cfg.deviceId != it.id) { cfg.deviceId = it.id; push(cfg) } }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(sp)
        val volTxt = text("Volumen: 100%", 14f)
        box.addView(volTxt)
        box.addView(SeekBar(this).apply {
            max = 150; progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    cfg.volume = p / 100f; volTxt.text = "Volumen: $p%"; if (u) push(cfg)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        box.addView(btn("Quitar") {
            Mixer.cfgs.remove(cfg); rows.removeAll { it.first === cfg }; rowsBox.removeView(box)
            if (helperOn) Thread { HelperClient.send("DEL ${cfg.uid}") }.start()
        })
        rowsBox.addView(box)
        rows += cfg to sp
        refreshDevices()
        push(cfg)
    }

    // ------------------------------------------------------------ modo captura (sin ADB)
    private fun toggleMixer() {
        if (helperOn) { Toast.makeText(this, "El modo ADB ya está activo, no hace falta", Toast.LENGTH_SHORT).show(); return }
        if (Mixer.running) {
            stopService(Intent(this, MixerService::class.java))
            mixBtn.text = "Iniciar mezclador (modo captura)"
        } else if (Mixer.cfgs.isEmpty()) {
            Toast.makeText(this, "Agregá al menos una app", Toast.LENGTH_SHORT).show()
        } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askPermissions()
        } else startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 42 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, MixerService::class.java).putExtra("code", res).putExtra("data", data))
            mixBtn.text = "Parar mezclador"
        }
    }

    override fun onDestroy() {
        if (micRunning) stopMic()
        super.onDestroy()
    }
}
